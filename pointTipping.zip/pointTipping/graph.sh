#!/bin/bash

prosv5 mu
prosv5 terminal > out.csv