#include <fstream>
#include "main.h"
#include "korvexlib.h"

// chassis
auto chassis = ChassisControllerBuilder() // two tracking wheels
		.withMotors({-LEFT_MTR2, LEFT_MTR1}, {RIGHT_MTR2, -RIGHT_MTR1})
		// green gearset, 4 inch wheel diameter, 8.125 inch wheelbase
		.withDimensions(AbstractMotor::gearset::green, {{4_in, 8.125_in}, imev5GreenTPR})
		.withSensors(
			ADIEncoder{'A', 'B'}, // left encoder in ADI ports A & B
			ADIEncoder{'E', 'F'}  // right encoder in ADI ports E & F
		)
		// specify the tracking wheels diameter (2.75 in), track (4.6 in), and TPR (360)
		.withOdometry({{2.75_in, 4.6_in}, quadEncoderTPR})
		.buildOdometry(); // build an odometry chassis

auto profileController = AsyncMotionProfileControllerBuilder()
    .withLimits({1.0, 1.8, 5.0}) //double maxVel double maxAccel double maxJerk
    .withOutput(chassis)
    .buildMotionProfileController();

// motors
okapi::Motor liftMotor(LIFT_MTR, false, AbstractMotor::gearset::red, AbstractMotor::encoderUnits::counts);
okapi::Motor trayMotor(TRAY_MTR, false, AbstractMotor::gearset::red, AbstractMotor::encoderUnits::counts);
okapi::MotorGroup intakeMotors({INTAKE_MTR1, -INTAKE_MTR2});

// controller
Controller masterController;
ControllerButton liftUp(ControllerDigital::R1);
ControllerButton liftDown(ControllerDigital::R2);
ControllerButton intakeIn(ControllerDigital::L1);
ControllerButton intakeOut(ControllerDigital::L2);
ControllerButton intakeShift(ControllerDigital::right);
ControllerButton flipoutBtn(ControllerDigital::left);
ControllerButton shift(ControllerDigital::Y);
ControllerButton trayReturn(ControllerDigital::X);
ControllerButton trayReturnAlt(ControllerDigital::A);
ControllerButton cubeReturn(ControllerDigital::B);

// sensors
pros::Imu imu(IMU_PORT);
pros::ADIAnalogIn line(LINE_PORT); // line sensor on tray, for cube detection
pros::ADIEncoder trackingLeft(1, 2);
pros::ADIEncoder trackingRight(5, 6);
pros::ADIEncoder trackingStrafe(3, 4, true);

// base global defenitions
const int LIFT_STACKING_HEIGHT = 700; // the motor ticks above which we are stacking
enum class autonStates { // the possible auton selections
	off,
	redProtec,
	redUnprotec,
	redRick,
	blueProtec,
	blueUnprotec,
	blueRick,
	skills
};
autonStates autonSelection = autonStates::off; // the current auton selection

enum class trayStates { // the possible tray states
	returned,
	returning,
	extending,
};
trayStates trayState = trayStates::returned; // the current tray state

enum class cubeStates { // the cube(line) sensor states, in this order
	uncovered,
	covered,
	setting,
	settingCovered,
	finished
};
cubeStates cubeState = cubeStates::covered;

// odom debug global
bool odomDebug = false;

// create a button descriptor string array
static const char *btnmMap[] = {"Unprotec", "Protec", "Rick", ""};

void driveP(int targetLeft, int targetRight, int voltageMax=115, bool debugLog=false) {

	// the touchables ;)))))))) touch me uwu :):):)
	float kp = 0.15;
	float acc = 5;
	float kpTurn = 0.7;
	float accTurn = 4;

	// the untouchables
	float voltageLeft = 0;
	float voltageRight = 0;
	int errorLeft;
	int errorRight;
	int voltageCap = 0;
	int signLeft;
	int signRight;
	int errorCurrent = 0;
	int errorLast = 0;
	int sameErrCycles = 0;
	int same0ErrCycles = 0;
	int startTime = pros::millis();
	targetLeft = targetLeft + chassis->getModel()->getSensorVals()[0];
	targetRight = targetRight + chassis->getModel()->getSensorVals()[1];


}

void driveQ(QLength targetX, QLength targetY, bool backwards=false, float voltageMax=115, bool forceFlip=false, bool debugLog=false) {

	// tune for straights
	float kp = 0.058;
	float ki = 0.0;
	float kd = 0.5;
	// fk yeah lets just keep tuning 30 mins before a match lmao

	// tune for turns
	float kpTurn = 0.0;
	float kiTurn = 0.03;
	float kdTurn = 0.0;

	// the untouchables
	float error; // distance to target
	float errorLast = 0; // error in the last loop
	float errorTheta; // targetTheta - robotTheta
	float errorLastTheta = 0; // errorTheta in the last loop
	float p; // proportional straight
	float i; // integral straight
	float d; // derivative straight
	float pTurn; // proportional turn
	float iTurn; // integral turn
	float dTurn; // derivative turn
	float voltageLeft;
	float voltageRight;
	float voltage; // calculated straight voltage
	float xDif = targetX.convert(centimeter) - chassis->getState().x.convert(centimeter); // target.x - robot.x
	float yDif = targetY.convert(centimeter) - chassis->getState().y.convert(centimeter); // target.y - robot.y
	float xOrig = chassis->getState().x.convert(centimeter); // original x coord
	float yOrig = chassis->getState().y.convert(centimeter); // original y coord
	float targetTheta = std::atan2(yDif,xDif)*180 / M_PI; // angle from origin to target
	float distanceTotal = std::sqrt(std::pow((targetX.convert(centimeter) - xOrig), 2) + std::pow((targetY.convert(centimeter) - yOrig), 2)); // total distance we need to travel
	float distanceOrig; // distance from original position
	int sameErrCycles = 0; // number of cycles we have stayed the same error
	int same0ErrCycles = 0; // number of cycles we have stayed at 0 error
	int startTime = pros::millis();

	if (backwards) targetTheta = std::atan(yDif/xDif)*180 / M_PI;
	if (forceFlip) targetTheta = -targetTheta; // i know its dumb
	voltageMax = voltageMax/127; // normalize the voltageMax


}

void turnP(int targetTurn, int voltageMax=127, bool debugLog=false) {

	// the touchables ;)))))))) touch me uwu :):):)
	float kp = 1.6;
	float ki = 0.8;
	float kd = 0.45;

	// the untouchables
	int voltageCap = 0;
	float voltage = 0;
	float errorCurrent;
	float errorLast;
	int errorCurrentInt;
	int errorLastInt;
	int sameErrCycles = 0;
	int same0ErrCycles = 0;
	int p;
	float i;
	int d;
	int sign;
	float error;
	int startTime = pros::millis();


}

void turnQ(QLength targetX, QLength targetY, bool backwards=false, bool forceFlip=false, bool debugLog=false) {
	// tune for turns
	float kp = 0.08;
	float ki = 0.0;
	float kd = 0.5;
	// who needs an I? i retuned during drivers meeting lmao

	// the untouchables
	float errorTheta; // targetTheta - robotTheta
	float errorLastTheta = 0; // errorTheta in the last loop
	float p; // proportional
	float i; // integral
	float d; // derivative
	float voltage; // calculated voltage
	float xDif = targetX.convert(centimeter) - chassis->getState().x.convert(centimeter); // target.x - robot.x
	float yDif = targetY.convert(centimeter) - chassis->getState().y.convert(centimeter); // target.y - robot.y
	float targetTheta = std::atan2(yDif,xDif)*180 / M_PI; // angle from robot to target, our goal angle
	int sameErrCycles = 0; // number of cycles we have stayed the same error
	int same0ErrCycles = 0; // number of cycles we have stayed at 0 error
	int startTime = pros::millis();

	if (backwards) targetTheta = std::atan(yDif/xDif)*180 / M_PI;
	if (forceFlip) targetTheta = -targetTheta;


}

void driveTo(QLength targetX, QLength targetY, bool backwards=false, int voltageMax=115, bool forceFlip=false, bool debugLog=false) {
	float targetTheta;
	if (backwards or forceFlip) targetTheta = std::atan((targetY.convert(centimeter) - chassis->getState().y.convert(centimeter))/(targetX.convert(centimeter) - chassis->getState().x.convert(centimeter)))*180 / M_PI;
	else targetTheta = std::atan2((targetY.convert(centimeter) - chassis->getState().y.convert(centimeter)), (targetX.convert(centimeter) - chassis->getState().x.convert(centimeter)))*180 / M_PI;
	if (abs(targetTheta - imu.get_rotation()) > 20) {turnQ(targetX, targetY, backwards, forceFlip, debugLog);} // only turn if the degree error is greater than 20 deg
	driveQ(targetX, targetY, backwards, voltageMax, forceFlip, debugLog);
}

void traySlew(bool forward) {
	if (forward) {
		if (trayMotor.getPosition() > 4500) trayMotor.moveVelocity(40);
		else trayMotor.moveVelocity(100);
	}
	else {
		if (trayMotor.getPosition() < 1000) trayMotor.moveVelocity(-60);
		else trayMotor.moveVelocity(-100);
	}
}

void generatePaths() { // all motion profile paths stored here, no real error correction in these
	// 8 cube s curve, mirror for red
	profileController->generatePath({
				{0_ft, 0_ft, 0_deg},
				{40_in, 10_in, 0_deg}},
				"9cCurve1"
			);
}

// a blocking flipout function
void flipout() {
	auto timer = TimeUtilFactory().create().getTimer();
	intakeMotors.moveVelocity(200);
	liftMotor.moveAbsolute(400, 200);
	timer->placeMark();
	while(line.get_value_calibrated_HR() > 46000 and timer->getDtFromMark().convert(second) < 0.5) pros::delay(20); // wait for the cube to get to position
	intakeMotors.moveVelocity(200);
	pros::delay(100);
	timer->placeMark();
	while(line.get_value_calibrated_HR() < 46000 and timer->getDtFromMark().convert(second) < 0.5) pros::delay(20); // move cube above position to initiate flipout
	intakeMotors.moveRelative(600, 200);
	pros::delay(20);
	while(abs(intakeMotors.getPositionError()) > 50) pros::delay(20); // save the cube yo
	intakeMotors.moveRelative(-600, 200);
	pros::delay(200);
	while(abs(intakeMotors.getPositionError()) > 5) pros::delay(20);
	liftMotor.moveAbsolute(-10, 100);
	pros::delay(200);
	while(abs(liftMotor.getPositionError()) > 40) pros::delay(20);
}

// just update calculated theta to actual theta using the imu
void odomImuSupplement (void*) {
	while (true) {
		chassis->setState({chassis->getState().x, chassis->getState().y, (((imu.get_rotation()*M_PI)/180) * okapi::radian)});
		if (odomDebug) std::cout << pros::millis() << ": pos  " << chassis->getState().str() << std::endl;
		pros::delay(20);
	}

}

static lv_res_t autonBtnmAction(lv_obj_t *btnm, const char *txt) {
	if (lv_obj_get_free_num(btnm) == 100) { // reds
		if (txt == "Unprotec") autonSelection = autonStates::redUnprotec;
		else if (txt == "Protec") autonSelection = autonStates::redProtec;
		else if (txt == "Rick") autonSelection = autonStates::redRick;
	}
	else if (lv_obj_get_free_num(btnm) == 101) { // blues
		if (txt == "Unprotec") autonSelection = autonStates::blueUnprotec;
		else if (txt == "Protec") autonSelection = autonStates::blueProtec;
		else if (txt == "Rick") autonSelection = autonStates::blueRick;
	}

	masterController.rumble("..");
	return LV_RES_OK; // return OK because the button matrix is not deleted
}

static lv_res_t skillsBtnAction(lv_obj_t *btn) {
	masterController.rumble("..");
	autonSelection = autonStates::skills;
	return LV_RES_OK;
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */

void initialize() {
	// save some time
	imu.reset();
	std::cout << pros::millis() << ": calibrating imu..." << std::endl;
	line.calibrate();
	std::cout << pros::millis() << ": calibrating line tracker..." << std::endl;

	// lvgl theme
	lv_theme_t *th = lv_theme_alien_init(360, NULL); //Set a HUE value and keep font default RED
	lv_theme_set_current(th);

	// create a tab view object
	std::cout << pros::millis() << ": creating gui..." << std::endl;
	lv_obj_t *tabview = lv_tabview_create(lv_scr_act(), NULL);

	// add 4 tabs (the tabs are page (lv_page) and can be scrolled
	lv_obj_t *redTab = lv_tabview_add_tab(tabview, "Red");
	lv_obj_t *blueTab = lv_tabview_add_tab(tabview, "Blue");
	lv_obj_t *skillsTab = lv_tabview_add_tab(tabview, "Skills");
	lv_obj_t *telemetryTab = lv_tabview_add_tab(tabview, "Telemetry");

	// red tab
	lv_obj_t *redBtnm = lv_btnm_create(redTab, NULL);
	lv_btnm_set_map(redBtnm, btnmMap);
	lv_btnm_set_action(redBtnm, autonBtnmAction);
	lv_obj_set_size(redBtnm, 450, 50);
	lv_btnm_set_toggle(redBtnm, true, 3);
	lv_obj_set_pos(redBtnm, 0, 100);
	lv_obj_align(redBtnm, NULL, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_free_num(redBtnm, 100);

	// blue tab
	lv_obj_t *blueBtnm = lv_btnm_create(blueTab, NULL);
	lv_btnm_set_map(blueBtnm, btnmMap);
	lv_btnm_set_action(blueBtnm, autonBtnmAction);
	lv_obj_set_size(blueBtnm, 450, 50);
	lv_btnm_set_toggle(blueBtnm, true, 3);
	lv_obj_set_pos(blueBtnm, 0, 100);
	lv_obj_align(blueBtnm, NULL, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_free_num(blueBtnm, 101);

	// skills tab
	lv_obj_t *skillsBtn = lv_btn_create(skillsTab, NULL);
	lv_obj_t *label = lv_label_create(skillsBtn, NULL);
	lv_label_set_text(label, "Skills");
	lv_btn_set_action(skillsBtn, LV_BTN_ACTION_CLICK, skillsBtnAction);
	lv_obj_set_size(skillsBtn, 450, 50);
	lv_btnm_set_toggle(skillsBtn, true, 1);
	lv_obj_set_pos(skillsBtn, 0, 100);
	lv_obj_align(skillsBtn, NULL, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_free_num(skillsBtn, 102);

	// debug
	lv_obj_t *msgBox = lv_mbox_create(telemetryTab, NULL);
	lv_mbox_set_text(msgBox, "rick from r");
	lv_obj_align(msgBox, NULL, LV_ALIGN_CENTER, 0, 20);
	lv_mbox_set_anim_time(msgBox, 300);
	lv_mbox_start_auto_close(msgBox, 2000);

	std::cout << pros::millis() << ": finished creating gui!" << std::endl;

	// generate paths
	std::cout << pros::millis() << ": generating paths..." << std::endl;
	generatePaths();
	std::cout << pros::millis() << ": finished generating paths..." << std::endl;

	// wait for calibrate
	while (imu.is_calibrating() and pros::millis() < 3000) pros::delay(20);
	if (pros::millis() < 3000) std::cout << pros::millis() << ": finished calibrating!" << std::endl;
	else {
		masterController.rumble(".. -");
		std::cout << pros::millis() << ": calibration failed, moving on" << std::endl;
	}

	// start imu implementation to odom
	pros::Task odomImuSupplementTask(odomImuSupplement, (void*)NULL, TASK_PRIORITY_DEFAULT-1, TASK_STACK_DEPTH_DEFAULT, "odomImuSUpplement");
	std::cout << pros::millis() << " odomImuSupplement state:" << odomImuSupplementTask.get_state();

	// log motor temps
	std::cout << pros::millis() << "\n" << pros::millis() << ": motor temps:" << std::endl;
	std::cout << pros::millis() << ": lift: " << liftMotor.getTemperature() << std::endl;
	std::cout << pros::millis() << ": tray: " << trayMotor.getTemperature() << std::endl;
	std::cout << pros::millis() << ": intake: " << intakeMotors.getTemperature() << std::endl;

}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {
	chassis->stop();
}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default pchassiosisioriority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */



void opcontrol() {
	chassis->stop();
	chassis->getModel()->setBrakeMode(AbstractMotor::brakeMode::coast);
	trayMotor.setBrakeMode(okapi::AbstractMotor::brakeMode::hold);
	chassis->setMaxVelocity(200);
	float joystickAvg = 0; // an average of the left and right joystick values
	bool cubesPositioning = false; // true when we are moving the cubes down to the line sensor, for stacking
	bool trayDebug = false; // im lazy
	bool cubeDebug = false; // still lazy
	auto timer = TimeUtilFactory().create().getTimer();

	// main loop
	while (true) {
		// basic lift control
		if (liftUp.isPressed()) liftMotor.moveVelocity(100);
		else if (liftDown.isPressed()) liftMotor.moveVelocity(-100);
		else if (liftMotor.getPosition() < LIFT_STACKING_HEIGHT and liftMotor.getPosition() > LIFT_STACKING_HEIGHT - 300) liftMotor.moveVoltage(-2000); // basically to force the lift down but not burn the motor, shut off the motor when we stabalize at 0
		else if (liftMotor.getPosition() < LIFT_STACKING_HEIGHT and liftMotor.getEfficiency() > 50) liftMotor.moveVoltage(-2000);
		else liftMotor.moveVoltage(0);

		// flipout routine
		if (flipoutBtn.changedToPressed()) flipout();

		// advanced intake control, with goal-oriented assists

		// auto cube positioning for stacking
		if (cubeReturn.isPressed()) {
			cubesPositioning = true; // outake until we detect cube or timeout
			timer->placeMark();
		}
		if (timer->getDtFromMark().convert(second) > 1) cubesPositioning = false; // timeout just in case

		if (cubesPositioning) {
			if (cubeState == cubeStates::settingCovered) {
				if (abs(intakeMotors.getPositionError()) <= 20) { // we finished setting the cube
					cubeState = cubeStates::finished;
					cubesPositioning = 0;
					if (cubeDebug) std::cout << pros::millis() << ": cubeState finished" << std::endl;
				}
			}
			else if (line.get_value_calibrated_HR() < 46000) { // if we are already covering, move up to uncover
				if (cubeState == cubeStates::setting) { // this means we have found cube position, so we must move it to its final position
					intakeMotors.moveRelative(-280, 100);
					cubeState = cubeStates::settingCovered;
					if (cubeDebug) std::cout << pros::millis() << ": cubeState settingCovered" << std::endl;
				}
				else intakeMotors.moveVelocity(100);
				if (cubeDebug) std::cout << pros::millis() << ": cubeState uncovering" << std::endl;
			}
			else { // if we arent covering the sensor and we arent setting the final position
				intakeMotors.moveVelocity(-100);
				cubeState = cubeStates::setting;
				if (cubeDebug) std::cout << pros::millis() << ": cubeState setting" << std::endl;
			}
		}

		// user controlled intake only enabled while returned
		if (trayState == trayStates::returned and not shift.isPressed()) { // if nothing else is controlling the intake and we arent moving the tray
			if (intakeIn.isPressed() and not intakeOut.isPressed() and liftMotor.getPosition() > LIFT_STACKING_HEIGHT) intakeMotors.moveVelocity(100); // if we are dumping into tower, redue intake velocity as not to shoot the cube halfway accross the field
			else if (intakeIn.isPressed() and not intakeOut.isPressed()) intakeMotors.moveVelocity(200);
			else if (intakeOut.isPressed() and liftMotor.getPosition() > LIFT_STACKING_HEIGHT) intakeMotors.moveVelocity(-100);
			else if (intakeOut.isPressed() or (intakeShift.isPressed() and liftMotor.getPosition() > LIFT_STACKING_HEIGHT)) intakeMotors.moveVelocity(-200);
			else if (not cubesPositioning) intakeMotors.moveVoltage(0);
		}

		// advanced tray control, also with goal-oriented assists
		if (trayReturn.changedToPressed()) { // manual tray toggle requests, this is highest priority control
			if (trayState == trayStates::returned) { // if we are already returned, move the tray out
				trayMotor.moveAbsolute(6300, 90);
				trayState = trayStates::extending;
			}
			else { // return to default tray position
				trayMotor.moveAbsolute(0, 100);
				trayState = trayStates::returning;
			}
		}
		else if (trayReturnAlt.changedToPressed()) { // a slower, further tray movement for high stacks
			if (trayState == trayStates::returned) { // if we are already returned, move the tray out
				trayMotor.moveAbsolute(6600, 65);
				trayState = trayStates::extending;
			}
			else { // return to default tray position
				trayMotor.moveAbsolute(0, 100);
				trayState = trayStates::returning;
			}
		}

		// update trayState
		if (trayMotor.getPosition() <= 100 and abs(trayMotor.getActualVelocity()) <= 5 and trayState != trayStates::extending) trayState = trayStates::returned; // let functions know if weve returned
		else if (trayMotor.getPosition() >= 6000) trayState = trayStates::returning;

		// tray control using shift key
		if (trayState == trayStates::returned) {
			if (shift.isPressed()) {
				if (intakeIn.isPressed()) traySlew(true);
				else if (intakeOut.isPressed()) traySlew(false);
				else trayMotor.moveVoltage(0);
			}
			// adjust tray based on lift position
			else if (liftMotor.getPosition() > LIFT_STACKING_HEIGHT) trayMotor.moveAbsolute(600, 100);
			else if (liftMotor.getPosition() <= LIFT_STACKING_HEIGHT and trayMotor.getPosition() <= 600) trayMotor.moveAbsolute(0, 100);
			else trayMotor.moveVoltage(0);
		}

		// tray stacking mods
		switch (trayState) {
			case trayStates::returned:
				intakeMotors.setBrakeMode(AbstractMotor::brakeMode::hold);
				chassis->getModel()->setBrakeMode(AbstractMotor::brakeMode::coast);
				if (trayDebug) std::cout << pros::millis() << ": trayState returned" << std::endl;
				break;
			case trayStates::returning:
				if (intakeIn.isPressed() and not intakeOut.isPressed()) intakeMotors.moveVelocity(200);
				else if (intakeOut.isPressed() or (intakeShift.isPressed())) intakeMotors.moveVelocity(-200);
				else if (joystickAvg > 0) intakeMotors.moveVoltage(0);
				else intakeMotors.moveVelocity((joystickAvg*350));
				intakeMotors.setBrakeMode(AbstractMotor::brakeMode::hold);
				chassis->getModel()->setBrakeMode(AbstractMotor::brakeMode::coast);
				if (trayDebug) std::cout << pros::millis() << ": trayState returning" << std::endl;
				break;
			case trayStates::extending:
				liftMotor.moveAbsolute(-150, 100);
				intakeMotors.setBrakeMode(AbstractMotor::brakeMode::coast);
				chassis->getModel()->setBrakeMode(AbstractMotor::brakeMode::hold);

				// the other intake control will not be used while we are stacking, all control is transfered to this block
				if (not shift.isPressed() and not shift.changedToReleased()) {
					if (intakeIn.isPressed()) intakeMotors.moveVelocity(50);
					else if (intakeOut.isPressed() or intakeShift.isPressed()) intakeMotors.moveVelocity(-50); // two ways to move stack down slowly
					else intakeMotors.moveVoltage(0);
				}
				if (trayDebug) std::cout << pros::millis() << ": trayState extending" << std::endl;
				break;
			default:
				break;
		}

		// lift brake mod
		if (liftMotor.getPosition() > LIFT_STACKING_HEIGHT) liftMotor.setBrakeMode(AbstractMotor::brakeMode::brake);
		else liftMotor.setBrakeMode(AbstractMotor::brakeMode::brake);

		chassis->getModel()->tank(masterController.getAnalog(ControllerAnalog::leftY),
								masterController.getAnalog(ControllerAnalog::rightY));


		// update vals
		joystickAvg = (masterController.getAnalog(ControllerAnalog::leftY) + (masterController.getAnalog(ControllerAnalog::rightY)) / 2);

		// debug
		// std::cout << pros::millis() << ": line " << line.get_value_calibrated_HR() << std::endl;
		// std::cout << pros::millis() << ": imu " << imu.get_heading() << std::endl;
		// std::cout << pros::millis() << ": lef " << trackingLeft.get_value() << std::endl;
		// std::cout << pros::millis() << ": rig " << trackingRight.get_value() << std::endl;
		pros::delay(20);
	}
}
